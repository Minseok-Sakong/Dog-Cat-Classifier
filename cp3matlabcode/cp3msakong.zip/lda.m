%Linear discriminant analysis training error rate is [49%].
%Linear discriminant analysis test error rate is [47%].

%This function takes in a training data matrix Xtrain, training
%label vector ytrain and uses them to compute the cat
%and dog sample mean vectors as well as the sample covariance matrix 
%(which is assumed to be equal for cats and dogs). 
%It also takes in a data matrix Xrun and produces a vector of
%label guesses yguess, corresponding to the ML rule for
%jointly Gaussian vectors with different means and the same 
%covariance matrix.
function yguess = lda(Xtrain,ytrain,Xrun)
nCat_tr = 0;
nDog_tr = 0;
[row,col] = size(Xrun);
yguess = zeros(row,1);
[N_tr,P_tr] = size(Xtrain);

for i = 1:N_tr
    if (ytrain(i) == -1)
        nCat_tr = nCat_tr +1; 
    else
        nDog_tr = nDog_tr +1;
    end
end

only_cat = zeros(nCat_tr, P_tr);
only_dog = zeros(nDog_tr, P_tr);
for i = 1:N_tr
    for j = 1:nCat_tr
        if (ytrain(i) == -1)
            only_cat(j,:) = Xtrain(i,:);
        end
    end
end

for i = 1:N_tr
    for j = 1:nDog_tr
        if (ytrain(i) == 1)
            only_dog(j,:) = Xtrain(i,:);
        end
    end
end
     
covc = cov(only_cat);
covd = cov(only_dog);
[mu_cat, mu_dog] = average_pet(Xtrain,ytrain);
newcat = transpose(mu_cat);
newdog = transpose(mu_dog);

covx = (1/(N_tr-2)).*((nCat_tr - 1).*covc + (nDog_tr - 1).*covd);

result1 = (2).*(Xrun)*pinv(covx)*(newdog - newcat);
result2 = (transpose(newdog)*pinv(covx)*newdog)-(transpose(newcat)*pinv(covx)*newcat);

for i = 1 : row
    if (result1(i) >= result2)
        yguess(i) = 1;
    else 
        yguess(i) = -1;
    end
end

end